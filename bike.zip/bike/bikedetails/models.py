from django.db import models
from django.db.models.base import Model

# Create your models here.

class AddBike(models.Model):
    Bike_Name = models.CharField(default='', max_length=100);
    Bike_Img = models.ImageField(default='', upload_to= 'Img1/')
    Bike_Price = models.IntegerField(default='0')
    Bike_Mileage = models.IntegerField(default='0')
    Bike_Speed = models.IntegerField(default='0')
    Bike_detail = models.CharField(default='', max_length=5000)
    Bike_offers = models.CharField(default="", max_length=5000)

    def __str__(self):
        return self.Bike_Name