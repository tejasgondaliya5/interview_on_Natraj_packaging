from django.urls import path
from . import views

urlpatterns = [
    path('', views.bikestatus, name='bikestatus'),
    path('addbike/', views.addbike, name='addbikes'),
    path('bikelist/', views.Bikelist, name='bikelist'),
    path('update/<int:A>', views.update, name='update'),
    path('delete/<int:B>', views.delete, name='delete'),
]