from django.shortcuts import redirect, render
from .models import *
# Create your views here.

def bikestatus(request):
    return render(request,'bikestatus.html')

def addbike(request):
    if request.POST:
        Bikename = request.POST['Bike_Name']
        Bikeimg =  request.FILES['Bike_Img']
        Bikeprice = request.POST['Bike_Price']
        Bikemileage = request.POST['Bike_Mileage']
        Bikespeed = request.POST['Bike_Speed']
        Bikedetail = request.POST['Bike_detail']
        Bikeoffers = request.POST['Bike_offers']

        obj = AddBike()

        obj.Bike_Name = Bikename
        obj.Bike_Img = Bikeimg
        obj.Bike_Price = Bikeprice
        obj.Bike_Mileage=Bikemileage
        obj.Bike_Speed=Bikespeed
        obj.Bike_detail = Bikedetail
        obj.Bike_offers = Bikeoffers

        obj.save()

    return render(request, 'addbike.html')

def Bikelist(request):
    data = AddBike.objects.all()
    return render(request, 'bikelist.html', {'data':data})

def update(request,A):
    data = AddBike.objects.get(id=A)
    if request.POST:
        data.Bike_Name = request.POST['Bike_Name']
        if request.FILES.get('file')==None:
            pass
        else:
            data.Bike_Img =  request.FILES['Bike_Img']
        data.Bike_Price = request.POST['Bike_Price']
        data.Bike_Mileage = request.POST['Bike_Mileage']
        data.Bike_Speed = request.POST['Bike_Speed']
        data.Bike_detail = request.POST['Bike_detail']
        data.Bike_offers = request.POST['Bike_offers']

        data.save()
        return redirect('bikelist')
    return render(request,'update.html', {'data':data})

def delete(request,B):
    data = AddBike.objects.get(id=B)
    data.delete()
    return redirect('bikelist')
    